import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'outline' | 'text';
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  fullWidth = false, 
  className = '', 
  ...props 
}) => {
  const baseStyles = "transition-all duration-300 font-sans tracking-wider uppercase text-xs md:text-sm py-3 px-8 rounded-sm font-medium";
  
  const variants = {
    // Gradient Rosé Gold with Graphite text for contrast/luxury
    primary: "bg-luxury-gradient text-graphite hover:bg-rose-gold-hover shadow-md hover:shadow-lg border border-transparent",
    // Outline with Gold Opaque
    outline: "border border-gold-opaque text-gold-opaque hover:bg-rose-gold hover:text-white hover:border-rose-gold",
    // Text style
    text: "text-rose-gold hover:text-gold-opaque underline-offset-4 hover:underline"
  };

  const widthClass = fullWidth ? "w-full" : "";

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${widthClass} ${className}`} 
      {...props}
    >
      {children}
    </button>
  );
};