import React from 'react';
import { MapPin, Phone, Instagram } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from './Button';

export const Footer: React.FC = () => {
  const handleWhatsAppClick = () => {
    // Add a small delay to allow the user to perceive the tactile animation
    setTimeout(() => {
      window.open('https://wa.me/5544998509063', '_blank');
    }, 200);
  };

  return (
    <footer id="contact" className="bg-nude-light pt-20 pb-10 border-t border-rose-gold/20">
      <div className="container mx-auto px-6">
        
        {/* Call to Action Area */}
        <div className="bg-white p-10 md:p-16 shadow-xl relative -mt-32 mb-20 rounded-sm">
           <div className="flex flex-col md:flex-row items-center justify-between gap-8">
             <div className="text-center md:text-left">
               <h3 className="font-serif text-3xl text-graphite mb-2">Pronta para realçar sua beleza?</h3>
               <p className="font-sans text-graphite/60">Agende agora mesmo o seu atendimento com elegância e naturalidade.</p>
             </div>
             <motion.div 
               className="shrink-0 flex gap-4"
               whileTap={{ scale: 0.95 }}
               transition={{ type: "spring", stiffness: 400, damping: 17 }}
             >
               <Button onClick={handleWhatsAppClick}>
                  Agendar pelo WhatsApp
               </Button>
             </motion.div>
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="md:col-span-1">
             <a href="#" className="font-serif text-2xl tracking-widest uppercase text-graphite block mb-4">
              Caroline de Melo Baratela
            </a>
            <p className="font-sans text-sm text-graphite/70 leading-relaxed font-medium">
              Designer de Sobrancelhas & Epiladora
            </p>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-sans font-bold text-xs uppercase tracking-widest text-graphite mb-6">Contato</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-graphite/70 text-sm">
                <MapPin size={18} className="text-gold-opaque shrink-0" />
                <span>Atendimento em Maringá – PR <br/>e Marialva - PR</span>
              </li>
              <li className="flex items-center gap-3 text-graphite/70 text-sm">
                <Phone size={18} className="text-gold-opaque shrink-0" />
                <span>(44) 99850-9063</span>
              </li>
            </ul>
          </div>

          {/* Hours */}
          <div>
            <h4 className="font-sans font-bold text-xs uppercase tracking-widest text-graphite mb-6">Horários</h4>
             <ul className="space-y-2 text-sm text-graphite/70 font-sans">
               <li className="flex justify-between">
                 <span>Segunda - Sábado</span>
               </li>
               <li className="text-xs italic opacity-70">
                 Horário a combinar
               </li>
             </ul>
          </div>

          {/* Social */}
          <div>
            <h4 className="font-sans font-bold text-xs uppercase tracking-widest text-graphite mb-6">Social</h4>
            <div className="flex space-x-4">
              <a href="https://instagram.com/cm.carolmelo" target="_blank" rel="noreferrer" className="w-10 h-10 rounded-full border border-gray-rose flex items-center justify-center text-graphite/70 hover:bg-rose-gold hover:border-rose-gold hover:text-white transition-all">
                <Instagram size={18} />
              </a>
            </div>
            <p className="text-xs text-graphite/60 mt-4">@cm.carolmelo</p>
          </div>
        </div>

        <div className="border-t border-gray-200 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-400 font-sans">
          <p>&copy; 2024 Caroline Melo Beauty Studio. Todos os direitos reservados.</p>
          <div className="flex space-x-6">
            <a href="#" className="hover:text-rose-gold">Privacidade</a>
            <a href="#" className="hover:text-rose-gold">Termos</a>
          </div>
        </div>
      </div>
    </footer>
  );
};