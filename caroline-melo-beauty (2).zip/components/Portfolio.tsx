import React from 'react';
import { motion } from 'framer-motion';

const results = [
  {
    id: 1,
    title: "Volume Russo",
    img: "https://images.unsplash.com/photo-1594824476961-b7b842250000?q=80&w=2670&auto=format&fit=crop",
    category: "Cílios"
  },
  {
    id: 2,
    title: "Design Natural",
    img: "https://images.unsplash.com/photo-1512413316925-fd4b93f31521?q=80&w=2574&auto=format&fit=crop",
    category: "Sobrancelhas"
  },
  {
    id: 3,
    title: "Brow Lamination",
    img: "https://images.unsplash.com/photo-1616683693504-3ea7e9ad6fec?q=80&w=2574&auto=format&fit=crop",
    category: "Sobrancelhas"
  }
];

export const Portfolio: React.FC = () => {
  return (
    <section id="portfolio" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12">
          <div className="max-w-xl">
             <span className="text-rose-gold font-sans text-xs tracking-[0.2em] uppercase font-bold">
              Portfolio
            </span>
            <h2 className="font-serif text-4xl text-graphite mt-4 mb-4">
              Antes e Depois
            </h2>
            <p className="font-sans text-graphite/70 leading-relaxed">
              Resultados que transformam e elevam a autoestima. Aqui você vê a naturalidade, precisão e cuidado presentes em cada atendimento.
            </p>
          </div>
          <div className="hidden md:block">
            <a href="https://instagram.com/cm.carolmelo" target="_blank" rel="noreferrer" className="text-sm font-sans tracking-widest border-b border-rose-gold pb-1 hover:text-rose-gold transition-colors text-graphite">
              VER MAIS NO INSTAGRAM
            </a>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {results.map((item, index) => (
            <motion.div 
              key={item.id}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="group relative cursor-pointer"
            >
              <div className="aspect-[4/5] overflow-hidden bg-gray-rose/20">
                <img 
                  src={item.img} 
                  alt={item.title} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                />
              </div>
              <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                 <div className="text-center p-6 bg-white/95 backdrop-blur-sm shadow-lg transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 min-w-[180px]">
                    <p className="text-xs font-sans tracking-widest text-gold-opaque uppercase mb-2">{item.category}</p>
                    <h3 className="font-serif text-xl text-graphite">{item.title}</h3>
                 </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-12 text-center md:hidden">
           <a href="https://instagram.com/cm.carolmelo" target="_blank" rel="noreferrer" className="text-sm font-sans tracking-widest border-b border-rose-gold pb-1 text-graphite">
              VER MAIS NO INSTAGRAM
            </a>
        </div>
      </div>
    </section>
  );
};