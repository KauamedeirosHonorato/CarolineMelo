import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { Testimonial } from '../types';

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Amanda Silva",
    role: "Cliente desde 2021",
    content: "A Caroline é uma artista! Faço minhas sobrancelhas com ela há dois anos e não confio em mais ninguém. O design fica super natural e harmônico.",
    rating: 5
  },
  {
    id: 2,
    name: "Beatriz Costa",
    role: "Cliente Lash",
    content: "Já fiz extensão de cílios em vários lugares, mas a técnica dela é incomparável. Durabilidade incrível e zero incômodo. Me sinto uma diva!",
    rating: 5
  },
  {
    id: 3,
    name: "Fernanda Lima",
    role: "Cliente Brow Lamination",
    content: "O espaço é lindo, super aconchegante e o atendimento é impecável. A Brow Lamination mudou meu olhar completamente. Recomendo de olhos fechados.",
    rating: 5
  },
  {
    id: 4,
    name: "Juliana Almeida",
    role: "Cliente Micropigmentação",
    content: "Estava com muito medo de fazer micropigmentação, mas a Caroline me passou total segurança. O resultado ficou tão delicado que ninguém diz que é micro.",
    rating: 5
  },
  {
    id: 5,
    name: "Patrícia Souza",
    role: "Noiva",
    content: "Fiz o pacote de noiva e foi a melhor escolha. As fotos do casamento ficaram perfeitas graças ao design impecável. Atendimento de rainha!",
    rating: 5
  }
];

export const Testimonials: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [itemsToShow, setItemsToShow] = useState(1);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setItemsToShow(3);
      } else if (window.innerWidth >= 768) {
        setItemsToShow(2);
      } else {
        setItemsToShow(1);
      }
    };

    handleResize(); // Initial call
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const maxIndex = Math.max(0, testimonials.length - itemsToShow);

  // Correct index if resizing causes it to go out of bounds
  useEffect(() => {
    if (currentIndex > maxIndex) {
      setCurrentIndex(maxIndex);
    }
  }, [itemsToShow, maxIndex, currentIndex]);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev >= maxIndex ? 0 : prev + 1));
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev === 0 ? maxIndex : prev - 1));
  };

  const goToSlide = (index: number) => {
    // When clicking a dot, we might need to clamp the index for desktop view
    // so we don't show empty space at the end
    const target = Math.min(index, maxIndex);
    setCurrentIndex(target);
  };

  return (
    <section id="testimonials" className="py-24 bg-nude-light overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <span className="text-rose-gold font-sans text-xs tracking-[0.2em] uppercase font-bold">
            Depoimentos
          </span>
          <h2 className="font-serif text-4xl text-graphite mt-4 mb-4">Love Notes</h2>
          <div className="flex justify-center gap-1 text-gold-opaque mb-8">
            {[1, 2, 3, 4, 5].map(i => <Star key={i} size={16} fill="currentColor" />)}
          </div>
        </div>

        {/* Carousel Wrapper */}
        <div className="relative">
          {/* Navigation Buttons (Desktop/Tablet) */}
          <div className="absolute top-1/2 -translate-y-1/2 -left-4 lg:-left-12 z-10 hidden md:block">
            <button 
              onClick={prevSlide}
              className="w-12 h-12 rounded-full border border-rose-gold/30 bg-white/80 backdrop-blur-sm text-rose-gold hover:bg-rose-gold hover:text-white transition-all flex items-center justify-center shadow-sm"
              aria-label="Previous testimonial"
            >
              <ChevronLeft size={24} />
            </button>
          </div>
          
          <div className="absolute top-1/2 -translate-y-1/2 -right-4 lg:-right-12 z-10 hidden md:block">
            <button 
              onClick={nextSlide}
              className="w-12 h-12 rounded-full border border-rose-gold/30 bg-white/80 backdrop-blur-sm text-rose-gold hover:bg-rose-gold hover:text-white transition-all flex items-center justify-center shadow-sm"
              aria-label="Next testimonial"
            >
              <ChevronRight size={24} />
            </button>
          </div>

          {/* Slider Track */}
          <div className="overflow-hidden px-2 py-4">
            <motion.div 
              className="flex"
              initial={false}
              animate={{ x: `-${currentIndex * (100 / itemsToShow)}%` }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
            >
              {testimonials.map((t) => (
                <div 
                  key={t.id} 
                  className="flex-shrink-0 px-3"
                  style={{ width: `${100 / itemsToShow}%` }}
                >
                  <div className="bg-white p-8 md:p-10 shadow-sm border border-gray-rose/20 flex flex-col items-center text-center rounded-sm h-full hover:shadow-lg transition-shadow duration-300 relative group">
                    <div className="absolute top-6 left-6 text-nude-deep/20">
                      <Quote size={40} />
                    </div>
                    
                    <div className="mb-6 relative z-10 pt-4">
                      <p className="font-serif text-lg italic text-graphite/80 leading-loose">"{t.content}"</p>
                    </div>
                    
                    <div className="mt-auto border-t border-nude-light pt-6 w-full">
                       <h4 className="font-sans font-bold text-sm uppercase tracking-wider text-graphite">{t.name}</h4>
                       <p className="font-sans text-xs text-gold-opaque mt-1">{t.role}</p>
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Mobile Navigation Buttons (Below content) */}
          <div className="flex justify-between items-center mt-6 md:hidden px-4">
             <button 
              onClick={prevSlide}
              className="p-2 text-rose-gold hover:bg-rose-gold/10 rounded-full"
            >
              <ChevronLeft size={24} />
            </button>
             <button 
              onClick={nextSlide}
              className="p-2 text-rose-gold hover:bg-rose-gold/10 rounded-full"
            >
              <ChevronRight size={24} />
            </button>
          </div>

          {/* Dots Indicator */}
          <div className="flex justify-center gap-2 mt-8">
            {Array.from({ length: testimonials.length - itemsToShow + 1 }).map((_, idx) => (
              <button
                key={idx}
                onClick={() => goToSlide(idx)}
                className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                  currentIndex === idx 
                    ? 'bg-rose-gold w-6' 
                    : 'bg-gray-rose hover:bg-rose-gold/60'
                }`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};