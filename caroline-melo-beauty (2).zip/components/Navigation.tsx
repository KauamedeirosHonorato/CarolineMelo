import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

export const Navigation: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
  }, [isMobileMenuOpen]);

  const navLinks = [
    { name: 'Início', href: '#hero' },
    { name: 'Serviços', href: '#services' },
    { name: 'Visagismo', href: '#visagismo' },
    { name: 'Sobre', href: '#about' },
    { name: 'Resultados', href: '#portfolio' },
    { name: 'Depoimentos', href: '#testimonials' },
  ];

  return (
    <nav 
      className={`fixed w-full z-50 transition-all duration-500 ${
        isMobileMenuOpen 
          ? 'bg-transparent py-4' 
          : isScrolled 
            ? 'bg-white/95 backdrop-blur-md shadow-sm py-4' 
            : 'bg-transparent py-6'
      }`}
    >
      <div className="container mx-auto px-6 flex justify-between items-center relative z-50">
        {/* Logo */}
        <div className="flex flex-col items-center md:items-start">
          <a href="#" className={`font-serif text-3xl tracking-widest uppercase transition-colors duration-300 ${isScrolled || isMobileMenuOpen ? 'text-graphite' : 'text-graphite'}`}>
            Caroline Melo
          </a>
          <span className={`text-xs tracking-[0.3em] uppercase transition-colors duration-300 ${isScrolled || isMobileMenuOpen ? 'text-gold-opaque' : 'text-graphite/80'}`}>
            Beauty
          </span>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex space-x-8 items-center">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className={`font-sans text-sm tracking-widest uppercase transition-colors duration-300 ${
                isScrolled ? 'text-graphite hover:text-gold-opaque' : 'text-graphite hover:text-gold-opaque'
              }`}
            >
              {link.name}
            </a>
          ))}
          <a
             href="#contact"
             className={`px-6 py-2 border text-sm tracking-widest uppercase transition-all duration-300 ${
               isScrolled 
                ? 'border-gold-opaque text-gold-opaque hover:bg-gold-opaque hover:text-white' 
                : 'border-graphite text-graphite hover:bg-graphite hover:text-white'
             }`}
          >
            Agendar
          </a>
        </div>

        {/* Mobile Toggle */}
        <button 
          className={`md:hidden focus:outline-none transition-colors duration-300 ${isScrolled || isMobileMenuOpen ? 'text-graphite' : 'text-graphite'}`}
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <X size={32} /> : <Menu size={32} />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      <div 
        className={`fixed inset-0 bg-white z-40 flex flex-col justify-center items-center transition-all duration-300 ${
          isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible pointer-events-none'
        }`}
      >
        <div className="flex flex-col space-y-8 text-center p-6 w-full max-w-sm">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={() => setIsMobileMenuOpen(false)}
              className="font-serif text-2xl md:text-3xl text-graphite hover:text-rose-gold transition-colors"
            >
              {link.name}
            </a>
          ))}
          <div className="pt-8">
            <a
               href="#contact"
               onClick={() => setIsMobileMenuOpen(false)}
               className="px-10 py-4 bg-luxury-gradient text-graphite font-sans text-base tracking-widest uppercase shadow-lg block w-full text-center hover:opacity-90 transition-opacity"
            >
              Agendar Agora
            </a>
          </div>
        </div>
      </div>
    </nav>
  );
};