import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2 } from 'lucide-react';

export const About: React.FC = () => {
  const features = [
    "Atendimento com horário agendado",
    "Técnicas delicadas, seguras e atualizadas",
    "Materiais individuais e ambiente higienizado",
    "Resultados naturais e duradouros",
    "Atendimento acolhedor e cheio de propósito"
  ];

  return (
    <section id="about" className="py-24 bg-white relative overflow-hidden">
      {/* Decorative Background Elements */}
      <div className="absolute top-0 right-0 w-1/3 h-full bg-nude-light/50 -z-10" />
      <div className="absolute bottom-20 left-10 w-64 h-64 rounded-full bg-rose-gold/10 blur-3xl -z-10" />

      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          
          {/* Image Side */}
          <div className="w-full lg:w-1/2 relative">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative z-10"
            >
              <div className="relative aspect-[3/4] w-full max-w-md mx-auto overflow-hidden rounded-sm shadow-xl">
                <img 
                  src="https://images.unsplash.com/photo-1595152772835-219674b2a8a6?q=80&w=1780&auto=format&fit=crop" 
                  alt="Caroline Melo Profissional" 
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 border-[1px] border-white/20 m-4" />
              </div>
              {/* Offset decorative box */}
              <div className="absolute -bottom-6 -right-6 w-full h-full border border-gold-opaque/30 -z-10 hidden md:block" />
            </motion.div>
          </div>

          {/* Text Side */}
          <div className="w-full lg:w-1/2">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <span className="text-gold-opaque font-sans text-xs tracking-[0.2em] uppercase font-bold">
                Sobre Mim
              </span>
              <h2 className="font-serif text-4xl lg:text-5xl text-graphite mt-4 mb-6">
                Caroline Melo
              </h2>
              <div className="w-16 h-[2px] bg-rose-gold mb-8" />
              
              <div className="font-sans text-graphite/80 leading-relaxed space-y-4">
                <p>
                  Olá! Eu sou Caroline Melo, designer de sobrancelhas e epiladora há quase 10 anos, apaixonada por transformar olhares e proporcionar experiências únicas de cuidado.
                </p>
                <p>
                  Trabalho com técnicas avançadas, olhar detalhista e uma energia extremamente sensível — porque acredito que beleza e emocional caminham juntos. Meu propósito é oferecer um atendimento acolhedor, seguro e totalmente personalizado.
                </p>
                <p>
                  Cada cliente recebe atenção especial, respeito ao formato natural do rosto e um resultado que realça sua verdadeira beleza. Seja bem-vinda ao meu espaço. Aqui, você é cuidada com carinho, profissionalismo e intenção.
                </p>
              </div>

              {/* Methodology / Features */}
              <div className="mt-8 pt-8 border-t border-gray-100">
                <h4 className="font-serif text-xl text-graphite mb-6">Como Funciona o Atendimento</h4>
                <ul className="space-y-3">
                  {features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-3 text-sm font-sans text-graphite/80">
                      <CheckCircle2 size={18} className="text-gold-opaque shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-10">
                <div className="inline-block">
                  <h4 className="font-serif text-4xl text-rose-gold">10+</h4>
                  <p className="text-xs uppercase tracking-widest text-gray-rose mt-1">Anos de Experiência</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};